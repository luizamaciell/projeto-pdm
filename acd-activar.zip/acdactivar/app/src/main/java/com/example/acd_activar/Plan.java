package com.example.acd_activar;

import com.google.gson.annotations.SerializedName;

public class Plan {
    int id;
    @SerializedName("name")
    String nome;
    @SerializedName("price")
    String preco;
    @SerializedName("description")
    String descricao;
    @SerializedName("description1")
    String descricao1;

    @SerializedName("description2")
    String descricao2;

    @SerializedName("description3")
    String descricao3;

    @SerializedName("description4")
    String descricao4;

    public Plan(int id, String nome, String preco, String descricao,String descricao1,String descricao2, String descricao3, String descricao4 ) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
        this.descricao = descricao;
        this.descricao1 = descricao1;
        this.descricao2 = descricao2;
        this.descricao3 = descricao3;
        this.descricao4 = descricao4;
    }
}
