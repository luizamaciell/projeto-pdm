package com.example.acd_activar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MeuAdaptador extends RecyclerView.Adapter<MeuAdaptador.ViewHolder> {
    ArrayList<Acd> acds;

    public MeuAdaptador(ArrayList<Acd> acds) {
        this.acds = acds;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView txtNome;

        final TextView txtEndereco;
        final ImageView ivFoto;

        public ViewHolder(View view) {
            super(view);
            txtNome = (TextView) view.findViewById(R.id.txtNome);
            txtEndereco = (TextView) view.findViewById(R.id.txtEndereco);
            ivFoto = (ImageView) view.findViewById(R.id.ivFoto);
        }
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_acd, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Acd acd = acds.get(position);
        holder.txtNome.setText(acd.nome);
        holder.txtEndereco.setText(acd.endereco);
        holder.ivFoto.setImageResource(acd.foto);
    }

    @Override
    public int getItemCount() {
        return acds.size();
    }
}
