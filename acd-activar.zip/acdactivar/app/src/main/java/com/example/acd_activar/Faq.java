package com.example.acd_activar;

public class Faq {
    int id;
    String question;
    String answer;
    String details;


    public Faq(int id, String question, String answer, String details) {
        this.id = id;
        this.question = question;
        this.answer = answer;
        this.details = details;
    }
}

