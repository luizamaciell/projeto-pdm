package com.example.acd_activar;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;

public interface Api {
    String BASE_URL = "http://10.0.2.2/acd-Activar/api/";
    @GET("plans")
    Call<List<Plan>> getPlans();

    @GET("plans/{id}")
    Call<Plan> getPlan(@Path("id") int id);

    @GET("faqs")
    Call<List<Faq>> getFaqs();

    @GET("faqs/{id}")
    Call<Faq> getFaq(@Path("id") int id);

    @GET("user/login")
    Call<Login> loginWithGet(@Header("email") String username, @Header("password") String password);

}