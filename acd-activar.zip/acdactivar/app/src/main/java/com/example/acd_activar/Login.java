package com.example.acd_activar;

public class Login  {

    User user;

    public Login(User user) {
        this.user = user;
    }

}
