package com.example.acd_activar;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Details_Fragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Details_Fragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "id";


    // TODO: Rename and change types of parameters
    private int id;

    TextView txtQuestion;
    TextView txtDetails;



    public Details_Fragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param id Parameter 1.
     * @return A new instance of fragment FragmentDescription.
     */
    // TODO: Rename and change types and number of parameters
    public static Details_Fragment newInstance(int id) {
        Details_Fragment fragment = new Details_Fragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PARAM1, id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = getArguments().getInt(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_details_, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getFaq();
        txtQuestion= getView().findViewById(R.id.txtQuestion);
        txtDetails = getView().findViewById(R.id.txtDetails);
    }

    private void getFaq() {

        Call<Faq> call = RetrofitClient.getInstance().getMyApi().getFaq(this.id);
        Log.d("TESTE", "onResponse: " + call.toString());

        call.enqueue(new Callback<Faq>() {
            @Override
            public void onResponse(Call<Faq> call, Response<Faq> response) {
                Faq faq = response.body();
                txtQuestion.setText(faq.question);
                txtDetails.setText(faq.details);
                Log.d("TESTE", faq.details);

            }

            @Override
            public void onFailure(Call<Faq> call, Throwable t) {
                Log.d("TESTE", t.toString());
                // Toast.makeText(getContext(), "Ocorreu um erro", Toast.LENGTH_LONG).show();
            }
        });
    }
}