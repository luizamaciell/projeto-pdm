package com.example.acd_activar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentAcd#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentAcd extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentAcd() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment FragmentAcd.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentAcd newInstance(String param1, String param2) {
        FragmentAcd fragment = new FragmentAcd();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        gerarAcds();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_acd, container, false);
    }

    ArrayList<Acd>acds;

    private void gerarAcds() {
        acds = new ArrayList<Acd>();
        criarAcd("EnergiaTotal Fitness", "Rua das Flores, 123 - Centro, Porto Alegre", R.drawable.acd1);
        criarAcd("Pulso Forte Academia", "Avenida Gaúcha, 456 - Moinhos de Vento, Porto Alegre", R.drawable.acd2);
        criarAcd("Corpo em Harmonia Gym", "Travessa dos Pássaros, 789 - Petrópolis, Porto Alegre", R.drawable.img_1);
        criarAcd("Superação Fitness Club", "Largo do Sol, 210 - Bela Vista, Porto Alegre", R.drawable.img_2);
        criarAcd("Vitalidade Xtreme Studio", "Praça da Liberdade, 333 - Bom Fim, Porto Alegre", R.drawable.img_3);

    }
    //instancia o objeto contato e adiciona ao ArrayList<Contato>
    private void criarAcd(String nome, String endereco, int foto) {
        Acd acd = new Acd(nome, endereco, foto);
        acds.add(acd);
    }
    @Override
    public void onViewCreated(@NonNull View view, @NonNull Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView rvAcds = getView().findViewById(R.id.rvAcds);
        MeuAdaptador adaptador = new MeuAdaptador(acds);
        RecyclerView.LayoutManager layout =
                new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        rvAcds.setLayoutManager(layout);
        rvAcds.setAdapter(adaptador);
    }
}