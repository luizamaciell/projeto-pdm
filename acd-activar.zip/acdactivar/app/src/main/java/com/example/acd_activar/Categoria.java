package com.example.acd_activar;

public class Categoria {
    String nome;
    int foto;

    public Categoria(String nome, int foto){
        this.nome = nome;
        this.foto = foto;
    }
}
