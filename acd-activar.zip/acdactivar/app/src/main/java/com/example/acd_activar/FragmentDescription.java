package com.example.acd_activar;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link FragmentDescription#newInstance} factory method to
 * create an instance of this fragment.
 */
public class FragmentDescription extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "id";


    // TODO: Rename and change types of parameters
    private int id;

    TextView txtNome;
    TextView txtDescricao1;
    TextView txtDescricao2;

    TextView txtDescricao3;

    TextView txtDescricao4;


    public FragmentDescription() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param id Parameter 1.
     * @return A new instance of fragment FragmentDescription.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentDescription newInstance(int id) {
        FragmentDescription fragment = new FragmentDescription();
        Bundle args = new Bundle();
        args.putInt(ARG_PARAM1, id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            id = getArguments().getInt(ARG_PARAM1);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_description, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getPlan();
        txtNome = getView().findViewById(R.id.txtNome);
       txtDescricao1 = getView().findViewById(R.id.txtDescricao1);
       txtDescricao2 = getView().findViewById(R.id.txtDescricao2);
       txtDescricao3 = getView().findViewById(R.id.txtDescricao3);
       txtDescricao4 = getView().findViewById(R.id.txtDescricao4);
    }

    private void getPlan() {

        Call<Plan> call = RetrofitClient.getInstance().getMyApi().getPlan(this.id);
        Log.d("TESTE", "onResponse: " + call.toString());

       call.enqueue(new Callback<Plan>() {
            @Override
            public void onResponse(Call<Plan> call, Response<Plan> response) {
                Plan plan = response.body();
                txtNome.setText(plan.nome);
                txtDescricao1.setText(plan.descricao1);
                txtDescricao2.setText(plan.descricao2);
               txtDescricao3.setText(plan.descricao3);
               txtDescricao4.setText(plan.descricao4);
               Log.d("TESTE", plan.descricao2);

            }

            @Override
            public void onFailure(Call<Plan> call, Throwable t) {
                Log.d("TESTE", t.toString());
               // Toast.makeText(getContext(), "Ocorreu um erro", Toast.LENGTH_LONG).show();
            }
        });
    }
}