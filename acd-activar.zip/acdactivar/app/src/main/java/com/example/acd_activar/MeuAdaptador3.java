package com.example.acd_activar;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;
public class MeuAdaptador3 extends RecyclerView.Adapter<MeuAdaptador3.ViewHolder> {
    List<Faq> faqs;

    Context context;


    public MeuAdaptador3(List<Faq> faqs) {
        this.faqs = faqs;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView txtId;
        final TextView txtQuestion;
        final TextView txtAnswer;

        final CardView cardFaq;

        public ViewHolder(View view) {
            super(view);
            txtId = (TextView) view.findViewById(R.id.txtId);
            txtQuestion = (TextView) view.findViewById(R.id.txtQuestion);
            txtAnswer = (TextView) view.findViewById(R.id.txtAnswer);

            cardFaq = (CardView) view.findViewById(R.id.cardFaq);

        }
    }
    @NonNull
    @Override
    public MeuAdaptador3.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_faq, parent, false);

        context = parent.getContext();
        return new MeuAdaptador3.ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Faq faq = faqs.get(position);
        holder.txtId.setText("" + faq.id);
        holder.txtQuestion.setText(faq.question);
        holder.txtAnswer.setText(faq.answer);

        holder.cardFaq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = ((FragmentActivity) context).getSupportFragmentManager().beginTransaction();
                Details_Fragment fragmentDetails = Details_Fragment.newInstance(faq.id);
                fragmentTransaction.replace(R.id.fragmentContainerView, fragmentDetails);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });

    }

    @Override
    public int getItemCount() {
        return faqs.size();
    }
}

