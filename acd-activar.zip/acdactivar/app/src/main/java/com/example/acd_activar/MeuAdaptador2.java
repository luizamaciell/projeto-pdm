package com.example.acd_activar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MeuAdaptador2 extends RecyclerView.Adapter<MeuAdaptador2.ViewHolder> {
    List<Plan> plans;
    Context context;

    public MeuAdaptador2(List<Plan> planos) {
        this.plans = planos;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        final TextView txtId;
        final TextView txtNome;
        final TextView txtPreco;

        //final TextView txtDescricao;

        final CardView cdPlan;

        public ViewHolder(View view) {
            super(view);
            txtId = (TextView) view.findViewById(R.id.txtId);
            txtNome = (TextView) view.findViewById(R.id.txtNome);
            txtPreco = (TextView) view.findViewById(R.id.txtPreco);
           // txtDescricao = (TextView) view.findViewById(R.id.txtDescricao);
            cdPlan = (CardView) view .findViewById(R.id.cardPlan);
        }
    }
    @NonNull
    @Override
    public MeuAdaptador2.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_plan, parent, false);

        context = parent.getContext();
        return new MeuAdaptador2.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Plan plan = plans.get(position);
        holder.txtId.setText(""+plan.id);
        holder.txtNome.setText(plan.nome);
        holder.txtPreco.setText(plan.preco);
       // holder.txtDescricao.setText(plan.descricao);

        holder.cdPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentTransaction fragmentTransaction = ((FragmentActivity) context).getSupportFragmentManager().beginTransaction();
                FragmentDescription fragmentDescription = FragmentDescription.newInstance(plan.id);
                fragmentTransaction.replace(R.id.fragmentContainerView, fragmentDescription);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
    }

    @Override
    public int getItemCount() {
        return plans.size();
    }
}


