package com.example.acd_activar;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    Button btnLogin;
    EditText edtEmail;
    EditText edtPassword;

    public static String KEY_PREFERENCE = "prefs";
    public static String KEY_USER_DATA = "user";
    public static String KEY_USER_HEADER_EMAIL = "headerEmail";
    public static String KEY_USER_HEADER_PASSWORD = "headerPassword";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Intent it = getIntent();

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnRegister);




        Toast.makeText(getApplicationContext(), "Erro... ", Toast.LENGTH_LONG).show();

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TextView txtEmail = findViewById(R.id.edtEmail);
                TextView txtPassword = findViewById(R.id.edtPassword);

                loginWithGet(txtEmail.getText().toString(), txtPassword.getText().toString());
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Toast.makeText(getApplicationContext(), "Erro... ", Toast.LENGTH_LONG).show();

    }

    private void loginWithGet(String email, String password) {

        //TextView tvErrorLogin = getView().findViewById(R.id.tvErrorLogin);

        Call<Login> call = RetrofitClient.getInstance().getMyApi().loginWithGet(email, password);

        call.enqueue(new Callback<Login>() {
            @Override
            public void onResponse(Call<Login> call, Response<Login> response) {
                Login login = response.body();

                Log.d(" TESTE", "onResponse: " + login.user.getName());
                if(login.user.getName() != "") {
                    ///  tvErrorLogin.setText("Tudo certo!");

//                  Para trocar a MainActivity é necessário usar o get parent context

                    Intent it = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(it);
                }
            }

            @Override
            public void onFailure(Call<Login> call, Throwable t) {
                //tvErrorLogin.setText("Ocorreu um erro! Verifique o email e a senha!");
            }
        });

    }

//    private void saveData(String email, String password) {
//        SharedPreferences preferences = getSharedPreferences(KEY_PREFERENCE, MODE_PRIVATE);
//        SharedPreferences.Editor editor = preferences.edit();
//        editor.putString(KEY_USER_HEADER_EMAIL, email);
//        editor.putString(KEY_USER_HEADER_PASSWORD, password);
//        editor.commit();
//    }
//
//    private void saveData(User user) {
//        SharedPreferences preferences = getSharedPreferences(KEY_PREFERENCE, MODE_PRIVATE);
//        SharedPreferences.Editor editor = preferences.edit();
//        Gson gson = new Gson();
//        String userData = gson.toJson(user);
//        editor.putString(KEY_USER_DATA, userData);
//        editor.commit();
//    }
}