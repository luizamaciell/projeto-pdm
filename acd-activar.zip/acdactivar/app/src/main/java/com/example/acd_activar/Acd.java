package com.example.acd_activar;

public class Acd {

        String nome;
        String endereco;
        int foto;

        public Acd(String nome, String endereco, int foto) {
            this.nome = nome;
            this.endereco = endereco;
            this.foto = foto;
        }
    }

